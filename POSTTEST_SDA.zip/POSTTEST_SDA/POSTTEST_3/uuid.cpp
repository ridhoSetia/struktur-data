#include <iostream>
using namespace std;

int main()
{
    cout << system("uuidgen") << endl;
    return 0;
}
